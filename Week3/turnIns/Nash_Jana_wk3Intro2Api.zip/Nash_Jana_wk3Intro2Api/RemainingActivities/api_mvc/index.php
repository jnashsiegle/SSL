<?
/*
* 	======================================
*	PROJECT:  	SSL - LAB 09 PREP
*	FILE: 		index.php
*	AUTHOR:		Jana Nash-Siegle
*	CREATED: 	12/8/2015
*	======================================
*/
include("controllers/Action_Controller.php");

//remember that index.php is the one SINGLE point of entry

?>