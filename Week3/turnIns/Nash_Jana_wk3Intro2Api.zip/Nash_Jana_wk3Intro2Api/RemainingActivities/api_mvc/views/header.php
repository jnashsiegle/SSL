<?php
/*
* 	======================================
*	PROJECT:  	SSL - LAB 09 PREP
*	FILE: 		views/header.php
*	AUTHOR:		Jana Nash-Siegle
*	CREATED: 	12/8/2015
*	======================================
*/
?>
<!DOCTYPE html>
<html>
<head lang = "en">
	<meta charset = "UTF-8">
	<title>Yahoo Weather</title>
	<link rel = "stylesheet" href = "public/css/styles.css">
</head>
<body>

