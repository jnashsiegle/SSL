
function resetFunction() {
    document.getElementById("form_fruits").reset();
}
